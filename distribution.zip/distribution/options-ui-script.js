(function(modules) {
  var installedModules = {};
  function __webpack_require__(moduleId) {
    if (installedModules[moduleId]) {
      return installedModules[moduleId].exports;
    }
    var module = installedModules[moduleId] = {
      i: moduleId,
      l: false,
      exports: {}
    };
    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    module.l = true;
    return module.exports;
  }
  __webpack_require__.m = modules;
  __webpack_require__.c = installedModules;
  __webpack_require__.d = function(exports, name, getter) {
    if (!__webpack_require__.o(exports, name)) {
      Object.defineProperty(exports, name, {
        enumerable: true,
        get: getter
      });
    }
  };
  __webpack_require__.r = function(exports) {
    if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
      Object.defineProperty(exports, Symbol.toStringTag, {
        value: "Module"
      });
    }
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
  };
  __webpack_require__.t = function(value, mode) {
    if (mode & 1) value = __webpack_require__(value);
    if (mode & 8) return value;
    if (mode & 4 && typeof value === "object" && value && value.__esModule) return value;
    var ns = Object.create(null);
    __webpack_require__.r(ns);
    Object.defineProperty(ns, "default", {
      enumerable: true,
      value: value
    });
    if (mode & 2 && typeof value != "string") for (var key in value) __webpack_require__.d(ns, key, function(key) {
      return value[key];
    }.bind(null, key));
    return ns;
  };
  __webpack_require__.n = function(module) {
    var getter = module && module.__esModule ? function getDefault() {
      return module["default"];
    } : function getModuleExports() {
      return module;
    };
    __webpack_require__.d(getter, "a", getter);
    return getter;
  };
  __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  __webpack_require__.p = "";
  return __webpack_require__(__webpack_require__.s = 15);
})([ function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "c", (function() {
    return H;
  }));
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return h;
  }));
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return n;
  }));
  var n, l, u, i, t, o, r, f, e = {}, c = [], a = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
  function s(n, l) {
    for (var u in l) n[u] = l[u];
    return n;
  }
  function v(n) {
    var l = n.parentNode;
    l && l.removeChild(n);
  }
  function h(n, l, u) {
    var i, t = arguments, o = {};
    for (i in l) "key" !== i && "ref" !== i && (o[i] = l[i]);
    if (arguments.length > 3) for (u = [ u ], i = 3; i < arguments.length; i++) u.push(t[i]);
    if (null != u && (o.children = u), "function" == typeof n && null != n.defaultProps) for (i in n.defaultProps) void 0 === o[i] && (o[i] = n.defaultProps[i]);
    return y(n, o, l && l.key, l && l.ref, null);
  }
  function y(l, u, i, t, o) {
    var r = {
      type: l,
      props: u,
      key: i,
      ref: t,
      __k: null,
      __: null,
      __b: 0,
      __e: null,
      __d: void 0,
      __c: null,
      constructor: void 0,
      __v: o
    };
    return null == o && (r.__v = r), n.vnode && n.vnode(r), r;
  }
  function p() {
    return {};
  }
  function d(n) {
    return n.children;
  }
  function m(n, l) {
    this.props = n, this.context = l;
  }
  function w(n, l) {
    if (null == l) return n.__ ? w(n.__, n.__.__k.indexOf(n) + 1) : null;
    for (var u; l < n.__k.length; l++) if (null != (u = n.__k[l]) && null != u.__e) return u.__e;
    return "function" == typeof n.type ? w(n) : null;
  }
  function k(n) {
    var l, u;
    if (null != (n = n.__) && null != n.__c) {
      for (n.__e = n.__c.base = null, l = 0; l < n.__k.length; l++) if (null != (u = n.__k[l]) && null != u.__e) {
        n.__e = n.__c.base = u.__e;
        break;
      }
      return k(n);
    }
  }
  function g(l) {
    (!l.__d && (l.__d = !0) && u.push(l) && !i++ || o !== n.debounceRendering) && ((o = n.debounceRendering) || t)(_);
  }
  function _() {
    for (var n; i = u.length; ) n = u.sort((function(n, l) {
      return n.__v.__b - l.__v.__b;
    })), u = [], n.some((function(n) {
      var l, u, i, t, o, r, f;
      n.__d && (r = (o = (l = n).__v).__e, (f = l.__P) && (u = [], (i = s({}, o)).__v = i, 
      t = z(f, o, i, l.__n, void 0 !== f.ownerSVGElement, null, u, null == r ? w(o) : r), 
      T(u, o), t != r && k(o)));
    }));
  }
  function b(n, l, u, i, t, o, r, f, a, s) {
    var h, p, m, k, g, _, b, x, A, P = i && i.__k || c, C = P.length;
    for (a == e && (a = null != r ? r[0] : C ? w(i, 0) : null), u.__k = [], h = 0; h < l.length; h++) if (null != (k = u.__k[h] = null == (k = l[h]) || "boolean" == typeof k ? null : "string" == typeof k || "number" == typeof k ? y(null, k, null, null, k) : Array.isArray(k) ? y(d, {
      children: k
    }, null, null, null) : null != k.__e || null != k.__c ? y(k.type, k.props, k.key, null, k.__v) : k)) {
      if (k.__ = u, k.__b = u.__b + 1, null === (m = P[h]) || m && k.key == m.key && k.type === m.type) P[h] = void 0; else for (p = 0; p < C; p++) {
        if ((m = P[p]) && k.key == m.key && k.type === m.type) {
          P[p] = void 0;
          break;
        }
        m = null;
      }
      if (g = z(n, k, m = m || e, t, o, r, f, a, s), (p = k.ref) && m.ref != p && (x || (x = []), 
      m.ref && x.push(m.ref, null, k), x.push(p, k.__c || g, k)), null != g) {
        if (null == b && (b = g), A = void 0, void 0 !== k.__d) A = k.__d, k.__d = void 0; else if (r == m || g != a || null == g.parentNode) {
          n: if (null == a || a.parentNode !== n) n.appendChild(g), A = null; else {
            for (_ = a, p = 0; (_ = _.nextSibling) && p < C; p += 2) if (_ == g) break n;
            n.insertBefore(g, a), A = a;
          }
          "option" == u.type && (n.value = "");
        }
        a = void 0 !== A ? A : g.nextSibling, "function" == typeof u.type && (u.__d = a);
      } else a && m.__e == a && a.parentNode != n && (a = w(m));
    }
    if (u.__e = b, null != r && "function" != typeof u.type) for (h = r.length; h--; ) null != r[h] && v(r[h]);
    for (h = C; h--; ) null != P[h] && D(P[h], P[h]);
    if (x) for (h = 0; h < x.length; h++) j(x[h], x[++h], x[++h]);
  }
  function x(n) {
    return null == n || "boolean" == typeof n ? [] : Array.isArray(n) ? c.concat.apply([], n.map(x)) : [ n ];
  }
  function A(n, l, u, i, t) {
    var o;
    for (o in u) "children" === o || "key" === o || o in l || C(n, o, null, u[o], i);
    for (o in l) t && "function" != typeof l[o] || "children" === o || "key" === o || "value" === o || "checked" === o || u[o] === l[o] || C(n, o, l[o], u[o], i);
  }
  function P(n, l, u) {
    "-" === l[0] ? n.setProperty(l, u) : n[l] = "number" == typeof u && !1 === a.test(l) ? u + "px" : null == u ? "" : u;
  }
  function C(n, l, u, i, t) {
    var o, r, f, e, c;
    if (t ? "className" === l && (l = "class") : "class" === l && (l = "className"), 
    "style" === l) if (o = n.style, "string" == typeof u) o.cssText = u; else {
      if ("string" == typeof i && (o.cssText = "", i = null), i) for (e in i) u && e in u || P(o, e, "");
      if (u) for (c in u) i && u[c] === i[c] || P(o, c, u[c]);
    } else "o" === l[0] && "n" === l[1] ? (r = l !== (l = l.replace(/Capture$/, "")), 
    f = l.toLowerCase(), l = (f in n ? f : l).slice(2), u ? (i || n.addEventListener(l, N, r), 
    (n.l || (n.l = {}))[l] = u) : n.removeEventListener(l, N, r)) : "list" !== l && "tagName" !== l && "form" !== l && "type" !== l && "size" !== l && !t && l in n ? n[l] = null == u ? "" : u : "function" != typeof u && "dangerouslySetInnerHTML" !== l && (l !== (l = l.replace(/^xlink:?/, "")) ? null == u || !1 === u ? n.removeAttributeNS("http://www.w3.org/1999/xlink", l.toLowerCase()) : n.setAttributeNS("http://www.w3.org/1999/xlink", l.toLowerCase(), u) : null == u || !1 === u && !/^ar/.test(l) ? n.removeAttribute(l) : n.setAttribute(l, u));
  }
  function N(l) {
    this.l[l.type](n.event ? n.event(l) : l);
  }
  function z(l, u, i, t, o, r, f, e, c) {
    var a, v, h, y, p, w, k, g, _, x, A, P = u.type;
    if (void 0 !== u.constructor) return null;
    (a = n.__b) && a(u);
    try {
      n: if ("function" == typeof P) {
        if (g = u.props, _ = (a = P.contextType) && t[a.__c], x = a ? _ ? _.props.value : a.__ : t, 
        i.__c ? k = (v = u.__c = i.__c).__ = v.__E : ("prototype" in P && P.prototype.render ? u.__c = v = new P(g, x) : (u.__c = v = new m(g, x), 
        v.constructor = P, v.render = E), _ && _.sub(v), v.props = g, v.state || (v.state = {}), 
        v.context = x, v.__n = t, h = v.__d = !0, v.__h = []), null == v.__s && (v.__s = v.state), 
        null != P.getDerivedStateFromProps && (v.__s == v.state && (v.__s = s({}, v.__s)), 
        s(v.__s, P.getDerivedStateFromProps(g, v.__s))), y = v.props, p = v.state, h) null == P.getDerivedStateFromProps && null != v.componentWillMount && v.componentWillMount(), 
        null != v.componentDidMount && v.__h.push(v.componentDidMount); else {
          if (null == P.getDerivedStateFromProps && g !== y && null != v.componentWillReceiveProps && v.componentWillReceiveProps(g, x), 
          !v.__e && null != v.shouldComponentUpdate && !1 === v.shouldComponentUpdate(g, v.__s, x) || u.__v === i.__v) {
            for (v.props = g, v.state = v.__s, u.__v !== i.__v && (v.__d = !1), v.__v = u, u.__e = i.__e, 
            u.__k = i.__k, v.__h.length && f.push(v), a = 0; a < u.__k.length; a++) u.__k[a] && (u.__k[a].__ = u);
            break n;
          }
          null != v.componentWillUpdate && v.componentWillUpdate(g, v.__s, x), null != v.componentDidUpdate && v.__h.push((function() {
            v.componentDidUpdate(y, p, w);
          }));
        }
        v.context = x, v.props = g, v.state = v.__s, (a = n.__r) && a(u), v.__d = !1, v.__v = u, 
        v.__P = l, a = v.render(v.props, v.state, v.context), null != v.getChildContext && (t = s(s({}, t), v.getChildContext())), 
        h || null == v.getSnapshotBeforeUpdate || (w = v.getSnapshotBeforeUpdate(y, p)), 
        A = null != a && a.type == d && null == a.key ? a.props.children : a, b(l, Array.isArray(A) ? A : [ A ], u, i, t, o, r, f, e, c), 
        v.base = u.__e, v.__h.length && f.push(v), k && (v.__E = v.__ = null), v.__e = !1;
      } else null == r && u.__v === i.__v ? (u.__k = i.__k, u.__e = i.__e) : u.__e = $(i.__e, u, i, t, o, r, f, c);
      (a = n.diffed) && a(u);
    } catch (l) {
      u.__v = null, n.__e(l, u, i);
    }
    return u.__e;
  }
  function T(l, u) {
    n.__c && n.__c(u, l), l.some((function(u) {
      try {
        l = u.__h, u.__h = [], l.some((function(n) {
          n.call(u);
        }));
      } catch (l) {
        n.__e(l, u.__v);
      }
    }));
  }
  function $(n, l, u, i, t, o, r, f) {
    var a, s, v, h, y, p = u.props, d = l.props;
    if (t = "svg" === l.type || t, null != o) for (a = 0; a < o.length; a++) if (null != (s = o[a]) && ((null === l.type ? 3 === s.nodeType : s.localName === l.type) || n == s)) {
      n = s, o[a] = null;
      break;
    }
    if (null == n) {
      if (null === l.type) return document.createTextNode(d);
      n = t ? document.createElementNS("http://www.w3.org/2000/svg", l.type) : document.createElement(l.type, d.is && {
        is: d.is
      }), o = null, f = !1;
    }
    if (null === l.type) p !== d && n.data != d && (n.data = d); else {
      if (null != o && (o = c.slice.call(n.childNodes)), v = (p = u.props || e).dangerouslySetInnerHTML, 
      h = d.dangerouslySetInnerHTML, !f) {
        if (null != o) for (p = {}, y = 0; y < n.attributes.length; y++) p[n.attributes[y].name] = n.attributes[y].value;
        (h || v) && (h && v && h.__html == v.__html || (n.innerHTML = h && h.__html || ""));
      }
      A(n, d, p, t, f), h ? l.__k = [] : (a = l.props.children, b(n, Array.isArray(a) ? a : [ a ], l, u, i, "foreignObject" !== l.type && t, o, r, e, f)), 
      f || ("value" in d && void 0 !== (a = d.value) && a !== n.value && C(n, "value", a, p.value, !1), 
      "checked" in d && void 0 !== (a = d.checked) && a !== n.checked && C(n, "checked", a, p.checked, !1));
    }
    return n;
  }
  function j(l, u, i) {
    try {
      "function" == typeof l ? l(u) : l.current = u;
    } catch (l) {
      n.__e(l, i);
    }
  }
  function D(l, u, i) {
    var t, o, r;
    if (n.unmount && n.unmount(l), (t = l.ref) && (t.current && t.current !== l.__e || j(t, null, u)), 
    i || "function" == typeof l.type || (i = null != (o = l.__e)), l.__e = l.__d = void 0, 
    null != (t = l.__c)) {
      if (t.componentWillUnmount) try {
        t.componentWillUnmount();
      } catch (l) {
        n.__e(l, u);
      }
      t.base = t.__P = null;
    }
    if (t = l.__k) for (r = 0; r < t.length; r++) t[r] && D(t[r], u, i);
    null != o && v(o);
  }
  function E(n, l, u) {
    return this.constructor(n, u);
  }
  function H(l, u, i) {
    var t, o, f;
    n.__ && n.__(l, u), o = (t = i === r) ? null : i && i.__k || u.__k, l = h(d, null, [ l ]), 
    f = [], z(u, (t ? u : i || u).__k = l, o || e, e, void 0 !== u.ownerSVGElement, i && !t ? [ i ] : o ? null : u.childNodes.length ? c.slice.call(u.childNodes) : null, f, i || e, t), 
    T(f, l);
  }
  function I(n, l) {
    H(n, l, r);
  }
  function L(n, l) {
    var u, i;
    for (i in l = s(s({}, n.props), l), arguments.length > 2 && (l.children = c.slice.call(arguments, 2)), 
    u = {}, l) "key" !== i && "ref" !== i && (u[i] = l[i]);
    return y(n.type, u, l.key || n.key, l.ref || n.ref, null);
  }
  function M(n) {
    var l = {}, u = {
      __c: "__cC" + f++,
      __: n,
      Consumer: function(n, l) {
        return n.children(l);
      },
      Provider: function(n) {
        var i, t = this;
        return this.getChildContext || (i = [], this.getChildContext = function() {
          return l[u.__c] = t, l;
        }, this.shouldComponentUpdate = function(n) {
          t.props.value !== n.value && i.some((function(l) {
            l.context = n.value, g(l);
          }));
        }, this.sub = function(n) {
          i.push(n);
          var l = n.componentWillUnmount;
          n.componentWillUnmount = function() {
            i.splice(i.indexOf(n), 1), l && l.call(n);
          };
        }), n.children;
      }
    };
    return u.Consumer.contextType = u, u.Provider.__ = u, u;
  }
  n = {
    __e: function(n, l) {
      for (var u, i; l = l.__; ) if ((u = l.__c) && !u.__) try {
        if (u.constructor && null != u.constructor.getDerivedStateFromError && (i = !0, 
        u.setState(u.constructor.getDerivedStateFromError(n))), null != u.componentDidCatch && (i = !0, 
        u.componentDidCatch(n)), i) return g(u.__E = u);
      } catch (l) {
        n = l;
      }
      throw n;
    }
  }, l = function(n) {
    return null != n && void 0 === n.constructor;
  }, m.prototype.setState = function(n, l) {
    var u;
    u = this.__s !== this.state ? this.__s : this.__s = s({}, this.state), "function" == typeof n && (n = n(u, this.props)), 
    n && s(u, n), null != n && this.__v && (l && this.__h.push(l), g(this));
  }, m.prototype.forceUpdate = function(n) {
    this.__v && (this.__e = !0, n && this.__h.push(n), g(this));
  }, m.prototype.render = d, u = [], i = 0, t = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, 
  r = e, f = 0;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return action_opened;
  }));
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return action_closed;
  }));
  __webpack_require__.d(__webpack_exports__, "e", (function() {
    return blacklist_toggled_on;
  }));
  __webpack_require__.d(__webpack_exports__, "d", (function() {
    return blacklist_toggled_off;
  }));
  __webpack_require__.d(__webpack_exports__, "h", (function() {
    return glossary_toggled_on;
  }));
  __webpack_require__.d(__webpack_exports__, "g", (function() {
    return glossary_toggled_off;
  }));
  __webpack_require__.d(__webpack_exports__, "f", (function() {
    return glossary_link_clicked;
  }));
  __webpack_require__.d(__webpack_exports__, "k", (function() {
    return options_opened;
  }));
  __webpack_require__.d(__webpack_exports__, "l", (function() {
    return remove_blacklisted_site_clicked;
  }));
  __webpack_require__.d(__webpack_exports__, "c", (function() {
    return add_blacklisted_site_clicked;
  }));
  __webpack_require__.d(__webpack_exports__, "i", (function() {
    return language_choice_clicked;
  }));
  __webpack_require__.d(__webpack_exports__, "j", (function() {
    return new_installation;
  }));
  __webpack_require__.d(__webpack_exports__, "q", (function() {
    return updated;
  }));
  __webpack_require__.d(__webpack_exports__, "p", (function() {
    return unspecified_install_event;
  }));
  __webpack_require__.d(__webpack_exports__, "n", (function() {
    return tooltip_anchor_hovered;
  }));
  __webpack_require__.d(__webpack_exports__, "o", (function() {
    return tooltip_link_clicked;
  }));
  __webpack_require__.d(__webpack_exports__, "m", (function() {
    return term_list_calculated;
  }));
  const action_opened = "browser_addon_browser_action_opened";
  const action_closed = "browser_addon_browser_action_closed";
  const blacklist_toggled_on = "browser_addon_browser_action_blacklist_toggled_on";
  const blacklist_toggled_off = "browser_addon_browser_action_blacklist_toggled_off";
  const glossary_toggled_on = "browser_addon_browser_action_glossary_toggled_on";
  const glossary_toggled_off = "browser_addon_browser_action_glossary_toggled_off";
  const glossary_link_clicked = "browser_addon_browser_action_glossary_link_clicked";
  const options_opened = "browser_addon_options_page_opened";
  const remove_blacklisted_site_clicked = "browser_addon_options_page_remove_blacklisted_site_clicked";
  const add_blacklisted_site_clicked = "browser_addon_options_page_add_blacklisted_site_clicked";
  const language_choice_clicked = "browser_addon_options_page_language_choice_clicked";
  const new_installation = "browser_addon_new_installation";
  const updated = "browser_addon_updated";
  const unspecified_install_event = "browser_addon_unspecified_install_event";
  const tooltip_anchor_hovered = "browser_addon_tab_tooltip_anchor_hovered";
  const tooltip_link_clicked = "browser_addon_tab_tooltip_link_clicked";
  const term_list_calculated = "browser_addon_tab_term_list_calculated";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var webext_options_sync__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7);
  var webext_options_sync__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(webext_options_sync__WEBPACK_IMPORTED_MODULE_0__);
  __webpack_exports__["a"] = new webext_options_sync__WEBPACK_IMPORTED_MODULE_0___default.a({
    defaults: {
      blacklistedSites: [],
      lang: "auto",
      snippetsLastFetched: {
        en: 1591717064327,
        de: 1591717064327
      }
    },
    migrations: [ webext_options_sync__WEBPACK_IMPORTED_MODULE_0___default.a.migrations.removeUnused ],
    logging: true
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return sendMessageToContentScript;
  }));
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return sendMessageToBackgroundScript;
  }));
  function sendMessageToContentScript(message) {
    return browser.tabs.query({
      currentWindow: true,
      active: true
    }).then(tabs => browser.tabs.sendMessage(tabs[0].id, message)).catch(console.log);
  }
  function sendMessageToBackgroundScript(message) {
    return browser.runtime.sendMessage(message).catch(console.log);
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return track;
  }));
  var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6);
  var _options_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2);
  var _messaging__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3);
  !function() {
    const analytics = window.analytics = window.analytics || [];
    if (!analytics.initialize) {
      if (analytics.invoked) {
        window.console && console.error && console.error("Segment snippet included twice.");
      } else {
        analytics.invoked = !0;
        analytics.methods = [ "trackSubmit", "trackClick", "trackLink", "trackForm", "pageview", "identify", "reset", "group", "track", "ready", "alias", "debug", "page", "once", "off", "on" ];
        analytics.factory = function(t) {
          return function() {
            const e = Array.prototype.slice.call(arguments);
            e.unshift(t);
            analytics.push(e);
            return analytics;
          };
        };
        for (let t = 0; t < analytics.methods.length; t++) {
          const e = analytics.methods[t];
          analytics[e] = analytics.factory(e);
        }
        analytics.load = function(t, e) {
          const n = document.createElement("script");
          n.type = "text/javascript";
          n.async = !0;
          n.src = "https://cdn.segment.com/analytics.js/v1/" + t + "/analytics.min.js";
          const a = document.querySelectorAll("script")[0];
          a.parentNode.insertBefore(n, a);
          analytics._loadOptions = e;
        };
        analytics.SNIPPET_VERSION = "4.1.0";
        analytics.load(_config__WEBPACK_IMPORTED_MODULE_0__["c"]);
        analytics.page();
      }
    }
  }();
  function isFirefoxOrChrome() {
    if (Boolean(window.chrome) && (Boolean(window.chrome.webstore) || Boolean(window.chrome.runtime))) {
      return "chrome";
    }
    if (typeof InstallTrigger !== "undefined") {
      return "firefox";
    }
    console.log("!! browser identification unsuccessful");
    return "unknown";
  }
  async function track(title, _detailsObject = {}, _hostname) {
    const {version: version} = browser.runtime.getManifest();
    const browserName = isFirefoxOrChrome();
    const storageData = await _options_storage__WEBPACK_IMPORTED_MODULE_1__["a"].getAll();
    const hostname = _hostname || await Object(_messaging__WEBPACK_IMPORTED_MODULE_2__["b"])({
      subject: "getHostname"
    });
    const url = await Object(_messaging__WEBPACK_IMPORTED_MODULE_2__["b"])({
      subject: "getUrl"
    });
    const detailsObject = {
      ..._detailsObject,
      hostname: hostname,
      url: url,
      browserName: browserName,
      version: version,
      storageData: storageData
    };
    analytics.track(title, detailsObject);
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return m;
  }));
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return l;
  }));
  var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
  var t, u, r, i = 0, o = [], c = preact__WEBPACK_IMPORTED_MODULE_0__["b"].__r, f = preact__WEBPACK_IMPORTED_MODULE_0__["b"].diffed, e = preact__WEBPACK_IMPORTED_MODULE_0__["b"].__c, a = preact__WEBPACK_IMPORTED_MODULE_0__["b"].unmount;
  function v(t, r) {
    preact__WEBPACK_IMPORTED_MODULE_0__["b"].__h && preact__WEBPACK_IMPORTED_MODULE_0__["b"].__h(u, t, i || r), 
    i = 0;
    var o = u.__H || (u.__H = {
      __: [],
      __h: []
    });
    return t >= o.__.length && o.__.push({}), o.__[t];
  }
  function m(n) {
    return i = 1, p(E, n);
  }
  function p(n, r, i) {
    var o = v(t++, 2);
    return o.t = n, o.__c || (o.__c = u, o.__ = [ i ? i(r) : E(void 0, r), function(n) {
      var t = o.t(o.__[0], n);
      o.__[0] !== t && (o.__[0] = t, o.__c.setState({}));
    } ]), o.__;
  }
  function l(r, i) {
    var o = v(t++, 3);
    !preact__WEBPACK_IMPORTED_MODULE_0__["b"].__s && x(o.__H, i) && (o.__ = r, o.__H = i, 
    u.__H.__h.push(o));
  }
  function y(r, i) {
    var o = v(t++, 4);
    !preact__WEBPACK_IMPORTED_MODULE_0__["b"].__s && x(o.__H, i) && (o.__ = r, o.__H = i, 
    u.__h.push(o));
  }
  function d(n) {
    return i = 5, h((function() {
      return {
        current: n
      };
    }), []);
  }
  function s(n, t, u) {
    i = 6, y((function() {
      "function" == typeof n ? n(t()) : n && (n.current = t());
    }), null == u ? u : u.concat(n));
  }
  function h(n, u) {
    var r = v(t++, 7);
    return x(r.__H, u) ? (r.__H = u, r.__h = n, r.__ = n()) : r.__;
  }
  function T(n, t) {
    return i = 8, h((function() {
      return n;
    }), t);
  }
  function w(n) {
    var r = u.context[n.__c], i = v(t++, 9);
    return i.__c = n, r ? (null == i.__ && (i.__ = !0, r.sub(u)), r.props.value) : n.__;
  }
  function A(t, u) {
    preact__WEBPACK_IMPORTED_MODULE_0__["b"].useDebugValue && preact__WEBPACK_IMPORTED_MODULE_0__["b"].useDebugValue(u ? u(t) : t);
  }
  function F(n) {
    var r = v(t++, 10), i = m();
    return r.__ = n, u.componentDidCatch || (u.componentDidCatch = function(n) {
      r.__ && r.__(n), i[1](n);
    }), [ i[0], function() {
      i[1](void 0);
    } ];
  }
  function _() {
    o.some((function(t) {
      if (t.__P) try {
        t.__H.__h.forEach(g), t.__H.__h.forEach(q), t.__H.__h = [];
      } catch (u) {
        return t.__H.__h = [], preact__WEBPACK_IMPORTED_MODULE_0__["b"].__e(u, t.__v), !0;
      }
    })), o = [];
  }
  function g(n) {
    "function" == typeof n.u && n.u();
  }
  function q(n) {
    n.u = n.__();
  }
  function x(n, t) {
    return !n || t.some((function(t, u) {
      return t !== n[u];
    }));
  }
  function E(n, t) {
    return "function" == typeof t ? t(n) : t;
  }
  preact__WEBPACK_IMPORTED_MODULE_0__["b"].__r = function(n) {
    c && c(n), t = 0;
    var r = (u = n.__c).__H;
    r && (r.__h.forEach(g), r.__h.forEach(q), r.__h = []);
  }, preact__WEBPACK_IMPORTED_MODULE_0__["b"].diffed = function(t) {
    f && f(t);
    var u = t.__c;
    u && u.__H && u.__H.__h.length && (1 !== o.push(u) && r === preact__WEBPACK_IMPORTED_MODULE_0__["b"].requestAnimationFrame || ((r = preact__WEBPACK_IMPORTED_MODULE_0__["b"].requestAnimationFrame) || function(n) {
      var t, u = function() {
        clearTimeout(r), cancelAnimationFrame(t), setTimeout(n);
      }, r = setTimeout(u, 100);
      "undefined" != typeof window && (t = requestAnimationFrame(u));
    })(_));
  }, preact__WEBPACK_IMPORTED_MODULE_0__["b"].__c = function(t, u) {
    u.some((function(t) {
      try {
        t.__h.forEach(g), t.__h = t.__h.filter((function(n) {
          return !n.__ || q(n);
        }));
      } catch (r) {
        u.some((function(n) {
          n.__h && (n.__h = []);
        })), u = [], preact__WEBPACK_IMPORTED_MODULE_0__["b"].__e(r, t.__v);
      }
    })), e && e(t, u);
  }, preact__WEBPACK_IMPORTED_MODULE_0__["b"].unmount = function(t) {
    a && a(t);
    var u = t.__c;
    if (u && u.__H) try {
      u.__H.__.forEach(g);
    } catch (t) {
      preact__WEBPACK_IMPORTED_MODULE_0__["b"].__e(t, u.__v);
    }
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return BASE_URL;
  }));
  __webpack_require__.d(__webpack_exports__, "c", (function() {
    return SEGMENT_WRITE_KEY;
  }));
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return INSTALL_URL;
  }));
  __webpack_require__.d(__webpack_exports__, "d", (function() {
    return UNINSTALL_URL;
  }));
  const BASE_URL = "https://next.amboss.com/";
  const INSTALL_URL = "https://go.amboss.com/browser-plugin-install-en";
  const UNINSTALL_URL = "https://go.amboss.com/browser-plugin-uninstall-en";
  const SEGMENT_WRITE_KEY = "XS0G3taLBntvZPu5pRFQWHlEkP45pVuM";
}, function(module, exports, __webpack_require__) {
  "use strict";
  const webext_detect_page_1 = __webpack_require__(8);
  class OptionsSync {
    constructor(options) {
      const fullOptions = {
        defaults: {},
        storageName: "options",
        migrations: [],
        logging: true,
        ...options
      };
      this.storageName = fullOptions.storageName;
      this.defaults = fullOptions.defaults;
      if (fullOptions.logging === false) {
        this._log = () => {};
      }
      if (webext_detect_page_1.isBackgroundPage()) {
        chrome.management.getSelf(({installType: installType}) => {
          if (installType === "development") {
            this._applyDefinition(fullOptions);
          } else {
            chrome.runtime.onInstalled.addListener(() => this._applyDefinition(fullOptions));
          }
        });
      }
      this._handleFormUpdatesDebounced = this._handleFormUpdatesDebounced.bind(this);
    }
    _log(method, ...args) {
      console[method](...args);
    }
    async _applyDefinition(defs) {
      const options = {
        ...defs.defaults,
        ...await this.getAll()
      };
      this._log("group", "Appling definitions");
      this._log("info", "Current options:", options);
      if (defs.migrations && defs.migrations.length > 0) {
        this._log("info", "Running", defs.migrations.length, "migrations");
        defs.migrations.forEach(migrate => migrate(options, defs.defaults));
      }
      this._log("info", "Migrated options:", options);
      this._log("groupEnd");
      this.setAll(options);
    }
    _parseNumbers(options) {
      for (const name of Object.keys(options)) {
        if (options[name] === String(Number(options[name]))) {
          options[name] = Number(options[name]);
        }
      }
      return options;
    }
    async getAll() {
      const keys = await new Promise((resolve, reject) => {
        chrome.storage.sync.get({
          [this.storageName]: this.defaults
        }, result => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve(result);
          }
        });
      });
      return this._parseNumbers(keys[this.storageName]);
    }
    async setAll(newOptions) {
      return new Promise((resolve, reject) => {
        chrome.storage.sync.set({
          [this.storageName]: newOptions
        }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve();
          }
        });
      });
    }
    async set(newOptions) {
      return this.setAll({
        ...await this.getAll(),
        ...newOptions
      });
    }
    async syncForm(form) {
      const element = form instanceof HTMLFormElement ? form : document.querySelector(form);
      element.addEventListener("input", this._handleFormUpdatesDebounced);
      element.addEventListener("change", this._handleFormUpdatesDebounced);
      chrome.storage.onChanged.addListener((changes, namespace) => {
        if (namespace === "sync" && changes[this.storageName] && !element.contains(document.activeElement)) {
          this._applyToForm(changes[this.storageName].newValue, element);
        }
      });
      this._applyToForm(await this.getAll(), element);
    }
    _applyToForm(options, form) {
      this._log("group", "Updating form");
      for (const name of Object.keys(options)) {
        const els = form.querySelectorAll(`[name="${CSS.escape(name)}"]`);
        const [field] = els;
        if (field) {
          this._log("info", name, ":", options[name]);
          switch (field.type) {
           case "checkbox":
            field.checked = options[name];
            break;

           case "radio":
            {
              const [selected] = [ ...els ].filter(el => el.value === options[name]);
              if (selected) {
                selected.checked = true;
              }
              break;
            }

           default:
            field.value = options[name];
            break;
          }
          field.dispatchEvent(new InputEvent("input"));
        } else {
          this._log("warn", "Stored option {", name, ":", options[name], "} was not found on the page");
        }
      }
      this._log("groupEnd");
    }
    _handleFormUpdatesDebounced({target: target}) {
      if (this._timer) {
        clearTimeout(this._timer);
      }
      this._timer = setTimeout(() => {
        this._handleFormUpdates(target);
        this._timer = undefined;
      }, 600);
    }
    _handleFormUpdates(el) {
      const {name: name} = el;
      let {value: value} = el;
      if (!name || !el.validity.valid) {
        return;
      }
      switch (el.type) {
       case "select-one":
        value = el.options[el.selectedIndex].value;
        break;

       case "checkbox":
        value = el.checked;
        break;

       default:
        break;
      }
      this._log("info", "Saving option", el.name, "to", value);
      this.set({
        [name]: value
      });
    }
  }
  OptionsSync.migrations = {
    removeUnused(options, defaults) {
      for (const key of Object.keys(options)) {
        if (!(key in defaults)) {
          delete options[key];
        }
      }
    }
  };
  module.exports = OptionsSync;
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  function isBackgroundPage() {
    return location.pathname === "/_generated_background_page.html" && !location.protocol.startsWith("http") && Boolean(typeof chrome === "object" && chrome.runtime);
  }
  exports.isBackgroundPage = isBackgroundPage;
  function isContentScript() {
    return location.protocol.startsWith("http") && Boolean(typeof chrome === "object" && chrome.runtime);
  }
  exports.isContentScript = isContentScript;
  function isOptionsPage() {
    if (typeof chrome !== "object" || !chrome.runtime) {
      return false;
    }
    const {options_ui: options_ui} = chrome.runtime.getManifest();
    if (typeof options_ui !== "object" || typeof options_ui.page !== "string") {
      return false;
    }
    const url = new URL(options_ui.page, location.origin);
    return url.pathname === location.pathname && url.origin === location.origin;
  }
  exports.isOptionsPage = isOptionsPage;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var n = function(t, s, r, e) {
    var u;
    s[0] = 0;
    for (var h = 1; h < s.length; h++) {
      var p = s[h++], a = s[h] ? (s[0] |= p ? 1 : 2, r[s[h++]]) : s[++h];
      3 === p ? e[0] = a : 4 === p ? e[1] = Object.assign(e[1] || {}, a) : 5 === p ? (e[1] = e[1] || {})[s[++h]] = a : 6 === p ? e[1][s[++h]] += a + "" : p ? (u = t.apply(a, n(t, a, r, [ "", null ])), 
      e.push(u), a[0] ? s[0] |= 2 : (s[h - 2] = 0, s[h] = u)) : e.push(a);
    }
    return e;
  }, t = new Map;
  __webpack_exports__["a"] = function(s) {
    var r = t.get(this);
    return r || (r = new Map, t.set(this, r)), (r = n(this, r.get(s) || (r.set(s, r = function(n) {
      for (var t, s, r = 1, e = "", u = "", h = [ 0 ], p = function(n) {
        1 === r && (n || (e = e.replace(/^\s*\n\s*|\s*\n\s*$/g, ""))) ? h.push(0, n, e) : 3 === r && (n || e) ? (h.push(3, n, e), 
        r = 2) : 2 === r && "..." === e && n ? h.push(4, n, 0) : 2 === r && e && !n ? h.push(5, 0, !0, e) : r >= 5 && ((e || !n && 5 === r) && (h.push(r, 0, e, s), 
        r = 6), n && (h.push(r, n, 0, s), r = 6)), e = "";
      }, a = 0; a < n.length; a++) {
        a && (1 === r && p(), p(a));
        for (var l = 0; l < n[a].length; l++) t = n[a][l], 1 === r ? "<" === t ? (p(), h = [ h ], 
        r = 3) : e += t : 4 === r ? "--" === e && ">" === t ? (r = 1, e = "") : e = t + e[0] : u ? t === u ? u = "" : e += t : '"' === t || "'" === t ? u = t : ">" === t ? (p(), 
        r = 1) : r && ("=" === t ? (r = 5, s = e, e = "") : "/" === t && (r < 5 || ">" === n[a][l + 1]) ? (p(), 
        3 === r && (h = h[0]), r = h, (h = h[0]).push(2, 0, r), r = 0) : " " === t || "\t" === t || "\n" === t || "\r" === t ? (p(), 
        r = 2) : e += t), 3 === r && "!--" === e && (r = 4, h = h[0]);
      }
      return p(), h;
    }(s)), r), arguments, [])).length > 1 ? r : r[0];
  };
}, , , , , , function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var preact_module = __webpack_require__(0);
  var hooks_module = __webpack_require__(5);
  var htm_module = __webpack_require__(9);
  var tracking_helpers = __webpack_require__(4);
  var options_storage = __webpack_require__(2);
  var trash_icon_red = __webpack_require__.p + "e2a4df992ffd92ed10c8e8c93714a79f.png";
  var event_names = __webpack_require__(1);
  const html = htm_module["a"].bind(preact_module["a"]);
  const OptionsUi = () => {
    const [language, setLanguage] = Object(hooks_module["b"])("auto");
    const [blacklistedSites, setBlacklistedSites] = Object(hooks_module["b"])();
    const [blacklistInput, setBlacklistInput] = Object(hooks_module["b"])("");
    Object(hooks_module["a"])(() => {
      const getStorageData = async () => {
        const storageData = await options_storage["a"].getAll();
        setBlacklistedSites(storageData.blacklistedSites);
        setLanguage(storageData.lang);
      };
      getStorageData();
    }, []);
    Object(hooks_module["a"])(() => Object(tracking_helpers["a"])(event_names["k"]), []);
    const onBlacklistInputChange = e => {
      setBlacklistInput(e.target.value);
    };
    const removeBlacklistSite = site => {
      Object(tracking_helpers["a"])(event_names["l"], {
        blacklistedSiteNameRemoved: site
      });
      setBlacklistedSites(blacklistedSites.filter(i => i !== site));
    };
    const addBlacklistSite = () => {
      if (blacklistedSites.find(i => i === blacklistInput)) {
        console.log(`${blacklistInput} is already blacklisted`);
        Object(tracking_helpers["a"])(event_names["c"], {
          blacklistedSiteNameAdded: blacklistInput
        });
        return;
      }
      Object(tracking_helpers["a"])(`clicked blacklist add button success for ${blacklistInput}`);
      setBlacklistInput("");
      setBlacklistedSites([ ...blacklistedSites, blacklistInput ]);
    };
    const onLanguageRadioChange = e => {
      Object(tracking_helpers["a"])(event_names["i"], {
        previousLanguageChoice: language,
        newLanguageChoice: e.target.value
      });
      setLanguage(e.target.value);
    };
    const onSubmit = e => {
      e.preventDefault();
      options_storage["a"].set({
        blacklistedSites: blacklistedSites,
        lang: language
      });
    };
    return language && blacklistedSites && html`
		<form onSubmit=${onSubmit}>
			<div class="options_language_container">
				<h3>Language of Medical Terms</h3>
				<label for="lang_auto">
				<input
						type="radio"
						id="lang_auto"
						name="lang"
						value="auto"
						checked=${language === "auto"}
						onClick=${onLanguageRadioChange}
				/>
					${browser.i18n.getMessage("languageChoiceAuto")}
				</label>
				<label for="lang_en">
					<input
						type="radio"
						id="lang_en"
						name="lang"
						value="en"
						checked=${language === "en"}
						onClick=${onLanguageRadioChange}
					/>
					${browser.i18n.getMessage("languageChoiceEn")}
				</label>
				<label for="lang_de">
					<input
						type="radio"
						id="lang_de"
						name="lang"
						value="de"
						checked=${language === "de"}
						onClick=${onLanguageRadioChange}
					/>
					${browser.i18n.getMessage("languageChoiceDe")}
				</label>
			</div>
			<div class="options_blacklist_container">
				<h3>${browser.i18n.getMessage("blacklistedSitesTitle")}</h3>
				<ul>
					${!blacklistedSites.length && html`<li>There are no blacklisted sites</li>`}
					${Boolean(blacklistedSites.length) && blacklistedSites.map(site => html`
						<li>
							${site}
							<img src=${trash_icon_red} alt="Trash Can" className="trash_icon" onClick=${() => removeBlacklistSite(site)} />
						</li>
					`)}
				</ul>
				<input type="text" value=${blacklistInput} onChange=${onBlacklistInputChange} />
				<button onClick=${addBlacklistSite}>+</button>
			</div>
			<button type="submit">${browser.i18n.getMessage("submitOptionsButton")}</button>
		</form>
	`;
  };
  Object(preact_module["c"])(html`<${OptionsUi} />`, document.body);
} ]);
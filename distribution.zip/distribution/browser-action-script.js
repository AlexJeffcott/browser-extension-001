(function(modules) {
  var installedModules = {};
  function __webpack_require__(moduleId) {
    if (installedModules[moduleId]) {
      return installedModules[moduleId].exports;
    }
    var module = installedModules[moduleId] = {
      i: moduleId,
      l: false,
      exports: {}
    };
    modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
    module.l = true;
    return module.exports;
  }
  __webpack_require__.m = modules;
  __webpack_require__.c = installedModules;
  __webpack_require__.d = function(exports, name, getter) {
    if (!__webpack_require__.o(exports, name)) {
      Object.defineProperty(exports, name, {
        enumerable: true,
        get: getter
      });
    }
  };
  __webpack_require__.r = function(exports) {
    if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
      Object.defineProperty(exports, Symbol.toStringTag, {
        value: "Module"
      });
    }
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
  };
  __webpack_require__.t = function(value, mode) {
    if (mode & 1) value = __webpack_require__(value);
    if (mode & 8) return value;
    if (mode & 4 && typeof value === "object" && value && value.__esModule) return value;
    var ns = Object.create(null);
    __webpack_require__.r(ns);
    Object.defineProperty(ns, "default", {
      enumerable: true,
      value: value
    });
    if (mode & 2 && typeof value != "string") for (var key in value) __webpack_require__.d(ns, key, function(key) {
      return value[key];
    }.bind(null, key));
    return ns;
  };
  __webpack_require__.n = function(module) {
    var getter = module && module.__esModule ? function getDefault() {
      return module["default"];
    } : function getModuleExports() {
      return module;
    };
    __webpack_require__.d(getter, "a", getter);
    return getter;
  };
  __webpack_require__.o = function(object, property) {
    return Object.prototype.hasOwnProperty.call(object, property);
  };
  __webpack_require__.p = "";
  return __webpack_require__(__webpack_require__.s = 13);
})([ function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "c", (function() {
    return H;
  }));
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return h;
  }));
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return n;
  }));
  var n, l, u, i, t, o, r, f, e = {}, c = [], a = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
  function s(n, l) {
    for (var u in l) n[u] = l[u];
    return n;
  }
  function v(n) {
    var l = n.parentNode;
    l && l.removeChild(n);
  }
  function h(n, l, u) {
    var i, t = arguments, o = {};
    for (i in l) "key" !== i && "ref" !== i && (o[i] = l[i]);
    if (arguments.length > 3) for (u = [ u ], i = 3; i < arguments.length; i++) u.push(t[i]);
    if (null != u && (o.children = u), "function" == typeof n && null != n.defaultProps) for (i in n.defaultProps) void 0 === o[i] && (o[i] = n.defaultProps[i]);
    return y(n, o, l && l.key, l && l.ref, null);
  }
  function y(l, u, i, t, o) {
    var r = {
      type: l,
      props: u,
      key: i,
      ref: t,
      __k: null,
      __: null,
      __b: 0,
      __e: null,
      __d: void 0,
      __c: null,
      constructor: void 0,
      __v: o
    };
    return null == o && (r.__v = r), n.vnode && n.vnode(r), r;
  }
  function p() {
    return {};
  }
  function d(n) {
    return n.children;
  }
  function m(n, l) {
    this.props = n, this.context = l;
  }
  function w(n, l) {
    if (null == l) return n.__ ? w(n.__, n.__.__k.indexOf(n) + 1) : null;
    for (var u; l < n.__k.length; l++) if (null != (u = n.__k[l]) && null != u.__e) return u.__e;
    return "function" == typeof n.type ? w(n) : null;
  }
  function k(n) {
    var l, u;
    if (null != (n = n.__) && null != n.__c) {
      for (n.__e = n.__c.base = null, l = 0; l < n.__k.length; l++) if (null != (u = n.__k[l]) && null != u.__e) {
        n.__e = n.__c.base = u.__e;
        break;
      }
      return k(n);
    }
  }
  function g(l) {
    (!l.__d && (l.__d = !0) && u.push(l) && !i++ || o !== n.debounceRendering) && ((o = n.debounceRendering) || t)(_);
  }
  function _() {
    for (var n; i = u.length; ) n = u.sort((function(n, l) {
      return n.__v.__b - l.__v.__b;
    })), u = [], n.some((function(n) {
      var l, u, i, t, o, r, f;
      n.__d && (r = (o = (l = n).__v).__e, (f = l.__P) && (u = [], (i = s({}, o)).__v = i, 
      t = z(f, o, i, l.__n, void 0 !== f.ownerSVGElement, null, u, null == r ? w(o) : r), 
      T(u, o), t != r && k(o)));
    }));
  }
  function b(n, l, u, i, t, o, r, f, a, s) {
    var h, p, m, k, g, _, b, x, A, P = i && i.__k || c, C = P.length;
    for (a == e && (a = null != r ? r[0] : C ? w(i, 0) : null), u.__k = [], h = 0; h < l.length; h++) if (null != (k = u.__k[h] = null == (k = l[h]) || "boolean" == typeof k ? null : "string" == typeof k || "number" == typeof k ? y(null, k, null, null, k) : Array.isArray(k) ? y(d, {
      children: k
    }, null, null, null) : null != k.__e || null != k.__c ? y(k.type, k.props, k.key, null, k.__v) : k)) {
      if (k.__ = u, k.__b = u.__b + 1, null === (m = P[h]) || m && k.key == m.key && k.type === m.type) P[h] = void 0; else for (p = 0; p < C; p++) {
        if ((m = P[p]) && k.key == m.key && k.type === m.type) {
          P[p] = void 0;
          break;
        }
        m = null;
      }
      if (g = z(n, k, m = m || e, t, o, r, f, a, s), (p = k.ref) && m.ref != p && (x || (x = []), 
      m.ref && x.push(m.ref, null, k), x.push(p, k.__c || g, k)), null != g) {
        if (null == b && (b = g), A = void 0, void 0 !== k.__d) A = k.__d, k.__d = void 0; else if (r == m || g != a || null == g.parentNode) {
          n: if (null == a || a.parentNode !== n) n.appendChild(g), A = null; else {
            for (_ = a, p = 0; (_ = _.nextSibling) && p < C; p += 2) if (_ == g) break n;
            n.insertBefore(g, a), A = a;
          }
          "option" == u.type && (n.value = "");
        }
        a = void 0 !== A ? A : g.nextSibling, "function" == typeof u.type && (u.__d = a);
      } else a && m.__e == a && a.parentNode != n && (a = w(m));
    }
    if (u.__e = b, null != r && "function" != typeof u.type) for (h = r.length; h--; ) null != r[h] && v(r[h]);
    for (h = C; h--; ) null != P[h] && D(P[h], P[h]);
    if (x) for (h = 0; h < x.length; h++) j(x[h], x[++h], x[++h]);
  }
  function x(n) {
    return null == n || "boolean" == typeof n ? [] : Array.isArray(n) ? c.concat.apply([], n.map(x)) : [ n ];
  }
  function A(n, l, u, i, t) {
    var o;
    for (o in u) "children" === o || "key" === o || o in l || C(n, o, null, u[o], i);
    for (o in l) t && "function" != typeof l[o] || "children" === o || "key" === o || "value" === o || "checked" === o || u[o] === l[o] || C(n, o, l[o], u[o], i);
  }
  function P(n, l, u) {
    "-" === l[0] ? n.setProperty(l, u) : n[l] = "number" == typeof u && !1 === a.test(l) ? u + "px" : null == u ? "" : u;
  }
  function C(n, l, u, i, t) {
    var o, r, f, e, c;
    if (t ? "className" === l && (l = "class") : "class" === l && (l = "className"), 
    "style" === l) if (o = n.style, "string" == typeof u) o.cssText = u; else {
      if ("string" == typeof i && (o.cssText = "", i = null), i) for (e in i) u && e in u || P(o, e, "");
      if (u) for (c in u) i && u[c] === i[c] || P(o, c, u[c]);
    } else "o" === l[0] && "n" === l[1] ? (r = l !== (l = l.replace(/Capture$/, "")), 
    f = l.toLowerCase(), l = (f in n ? f : l).slice(2), u ? (i || n.addEventListener(l, N, r), 
    (n.l || (n.l = {}))[l] = u) : n.removeEventListener(l, N, r)) : "list" !== l && "tagName" !== l && "form" !== l && "type" !== l && "size" !== l && !t && l in n ? n[l] = null == u ? "" : u : "function" != typeof u && "dangerouslySetInnerHTML" !== l && (l !== (l = l.replace(/^xlink:?/, "")) ? null == u || !1 === u ? n.removeAttributeNS("http://www.w3.org/1999/xlink", l.toLowerCase()) : n.setAttributeNS("http://www.w3.org/1999/xlink", l.toLowerCase(), u) : null == u || !1 === u && !/^ar/.test(l) ? n.removeAttribute(l) : n.setAttribute(l, u));
  }
  function N(l) {
    this.l[l.type](n.event ? n.event(l) : l);
  }
  function z(l, u, i, t, o, r, f, e, c) {
    var a, v, h, y, p, w, k, g, _, x, A, P = u.type;
    if (void 0 !== u.constructor) return null;
    (a = n.__b) && a(u);
    try {
      n: if ("function" == typeof P) {
        if (g = u.props, _ = (a = P.contextType) && t[a.__c], x = a ? _ ? _.props.value : a.__ : t, 
        i.__c ? k = (v = u.__c = i.__c).__ = v.__E : ("prototype" in P && P.prototype.render ? u.__c = v = new P(g, x) : (u.__c = v = new m(g, x), 
        v.constructor = P, v.render = E), _ && _.sub(v), v.props = g, v.state || (v.state = {}), 
        v.context = x, v.__n = t, h = v.__d = !0, v.__h = []), null == v.__s && (v.__s = v.state), 
        null != P.getDerivedStateFromProps && (v.__s == v.state && (v.__s = s({}, v.__s)), 
        s(v.__s, P.getDerivedStateFromProps(g, v.__s))), y = v.props, p = v.state, h) null == P.getDerivedStateFromProps && null != v.componentWillMount && v.componentWillMount(), 
        null != v.componentDidMount && v.__h.push(v.componentDidMount); else {
          if (null == P.getDerivedStateFromProps && g !== y && null != v.componentWillReceiveProps && v.componentWillReceiveProps(g, x), 
          !v.__e && null != v.shouldComponentUpdate && !1 === v.shouldComponentUpdate(g, v.__s, x) || u.__v === i.__v) {
            for (v.props = g, v.state = v.__s, u.__v !== i.__v && (v.__d = !1), v.__v = u, u.__e = i.__e, 
            u.__k = i.__k, v.__h.length && f.push(v), a = 0; a < u.__k.length; a++) u.__k[a] && (u.__k[a].__ = u);
            break n;
          }
          null != v.componentWillUpdate && v.componentWillUpdate(g, v.__s, x), null != v.componentDidUpdate && v.__h.push((function() {
            v.componentDidUpdate(y, p, w);
          }));
        }
        v.context = x, v.props = g, v.state = v.__s, (a = n.__r) && a(u), v.__d = !1, v.__v = u, 
        v.__P = l, a = v.render(v.props, v.state, v.context), null != v.getChildContext && (t = s(s({}, t), v.getChildContext())), 
        h || null == v.getSnapshotBeforeUpdate || (w = v.getSnapshotBeforeUpdate(y, p)), 
        A = null != a && a.type == d && null == a.key ? a.props.children : a, b(l, Array.isArray(A) ? A : [ A ], u, i, t, o, r, f, e, c), 
        v.base = u.__e, v.__h.length && f.push(v), k && (v.__E = v.__ = null), v.__e = !1;
      } else null == r && u.__v === i.__v ? (u.__k = i.__k, u.__e = i.__e) : u.__e = $(i.__e, u, i, t, o, r, f, c);
      (a = n.diffed) && a(u);
    } catch (l) {
      u.__v = null, n.__e(l, u, i);
    }
    return u.__e;
  }
  function T(l, u) {
    n.__c && n.__c(u, l), l.some((function(u) {
      try {
        l = u.__h, u.__h = [], l.some((function(n) {
          n.call(u);
        }));
      } catch (l) {
        n.__e(l, u.__v);
      }
    }));
  }
  function $(n, l, u, i, t, o, r, f) {
    var a, s, v, h, y, p = u.props, d = l.props;
    if (t = "svg" === l.type || t, null != o) for (a = 0; a < o.length; a++) if (null != (s = o[a]) && ((null === l.type ? 3 === s.nodeType : s.localName === l.type) || n == s)) {
      n = s, o[a] = null;
      break;
    }
    if (null == n) {
      if (null === l.type) return document.createTextNode(d);
      n = t ? document.createElementNS("http://www.w3.org/2000/svg", l.type) : document.createElement(l.type, d.is && {
        is: d.is
      }), o = null, f = !1;
    }
    if (null === l.type) p !== d && n.data != d && (n.data = d); else {
      if (null != o && (o = c.slice.call(n.childNodes)), v = (p = u.props || e).dangerouslySetInnerHTML, 
      h = d.dangerouslySetInnerHTML, !f) {
        if (null != o) for (p = {}, y = 0; y < n.attributes.length; y++) p[n.attributes[y].name] = n.attributes[y].value;
        (h || v) && (h && v && h.__html == v.__html || (n.innerHTML = h && h.__html || ""));
      }
      A(n, d, p, t, f), h ? l.__k = [] : (a = l.props.children, b(n, Array.isArray(a) ? a : [ a ], l, u, i, "foreignObject" !== l.type && t, o, r, e, f)), 
      f || ("value" in d && void 0 !== (a = d.value) && a !== n.value && C(n, "value", a, p.value, !1), 
      "checked" in d && void 0 !== (a = d.checked) && a !== n.checked && C(n, "checked", a, p.checked, !1));
    }
    return n;
  }
  function j(l, u, i) {
    try {
      "function" == typeof l ? l(u) : l.current = u;
    } catch (l) {
      n.__e(l, i);
    }
  }
  function D(l, u, i) {
    var t, o, r;
    if (n.unmount && n.unmount(l), (t = l.ref) && (t.current && t.current !== l.__e || j(t, null, u)), 
    i || "function" == typeof l.type || (i = null != (o = l.__e)), l.__e = l.__d = void 0, 
    null != (t = l.__c)) {
      if (t.componentWillUnmount) try {
        t.componentWillUnmount();
      } catch (l) {
        n.__e(l, u);
      }
      t.base = t.__P = null;
    }
    if (t = l.__k) for (r = 0; r < t.length; r++) t[r] && D(t[r], u, i);
    null != o && v(o);
  }
  function E(n, l, u) {
    return this.constructor(n, u);
  }
  function H(l, u, i) {
    var t, o, f;
    n.__ && n.__(l, u), o = (t = i === r) ? null : i && i.__k || u.__k, l = h(d, null, [ l ]), 
    f = [], z(u, (t ? u : i || u).__k = l, o || e, e, void 0 !== u.ownerSVGElement, i && !t ? [ i ] : o ? null : u.childNodes.length ? c.slice.call(u.childNodes) : null, f, i || e, t), 
    T(f, l);
  }
  function I(n, l) {
    H(n, l, r);
  }
  function L(n, l) {
    var u, i;
    for (i in l = s(s({}, n.props), l), arguments.length > 2 && (l.children = c.slice.call(arguments, 2)), 
    u = {}, l) "key" !== i && "ref" !== i && (u[i] = l[i]);
    return y(n.type, u, l.key || n.key, l.ref || n.ref, null);
  }
  function M(n) {
    var l = {}, u = {
      __c: "__cC" + f++,
      __: n,
      Consumer: function(n, l) {
        return n.children(l);
      },
      Provider: function(n) {
        var i, t = this;
        return this.getChildContext || (i = [], this.getChildContext = function() {
          return l[u.__c] = t, l;
        }, this.shouldComponentUpdate = function(n) {
          t.props.value !== n.value && i.some((function(l) {
            l.context = n.value, g(l);
          }));
        }, this.sub = function(n) {
          i.push(n);
          var l = n.componentWillUnmount;
          n.componentWillUnmount = function() {
            i.splice(i.indexOf(n), 1), l && l.call(n);
          };
        }), n.children;
      }
    };
    return u.Consumer.contextType = u, u.Provider.__ = u, u;
  }
  n = {
    __e: function(n, l) {
      for (var u, i; l = l.__; ) if ((u = l.__c) && !u.__) try {
        if (u.constructor && null != u.constructor.getDerivedStateFromError && (i = !0, 
        u.setState(u.constructor.getDerivedStateFromError(n))), null != u.componentDidCatch && (i = !0, 
        u.componentDidCatch(n)), i) return g(u.__E = u);
      } catch (l) {
        n = l;
      }
      throw n;
    }
  }, l = function(n) {
    return null != n && void 0 === n.constructor;
  }, m.prototype.setState = function(n, l) {
    var u;
    u = this.__s !== this.state ? this.__s : this.__s = s({}, this.state), "function" == typeof n && (n = n(u, this.props)), 
    n && s(u, n), null != n && this.__v && (l && this.__h.push(l), g(this));
  }, m.prototype.forceUpdate = function(n) {
    this.__v && (this.__e = !0, n && this.__h.push(n), g(this));
  }, m.prototype.render = d, u = [], i = 0, t = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, 
  r = e, f = 0;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return action_opened;
  }));
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return action_closed;
  }));
  __webpack_require__.d(__webpack_exports__, "e", (function() {
    return blacklist_toggled_on;
  }));
  __webpack_require__.d(__webpack_exports__, "d", (function() {
    return blacklist_toggled_off;
  }));
  __webpack_require__.d(__webpack_exports__, "h", (function() {
    return glossary_toggled_on;
  }));
  __webpack_require__.d(__webpack_exports__, "g", (function() {
    return glossary_toggled_off;
  }));
  __webpack_require__.d(__webpack_exports__, "f", (function() {
    return glossary_link_clicked;
  }));
  __webpack_require__.d(__webpack_exports__, "k", (function() {
    return options_opened;
  }));
  __webpack_require__.d(__webpack_exports__, "l", (function() {
    return remove_blacklisted_site_clicked;
  }));
  __webpack_require__.d(__webpack_exports__, "c", (function() {
    return add_blacklisted_site_clicked;
  }));
  __webpack_require__.d(__webpack_exports__, "i", (function() {
    return language_choice_clicked;
  }));
  __webpack_require__.d(__webpack_exports__, "j", (function() {
    return new_installation;
  }));
  __webpack_require__.d(__webpack_exports__, "q", (function() {
    return updated;
  }));
  __webpack_require__.d(__webpack_exports__, "p", (function() {
    return unspecified_install_event;
  }));
  __webpack_require__.d(__webpack_exports__, "n", (function() {
    return tooltip_anchor_hovered;
  }));
  __webpack_require__.d(__webpack_exports__, "o", (function() {
    return tooltip_link_clicked;
  }));
  __webpack_require__.d(__webpack_exports__, "m", (function() {
    return term_list_calculated;
  }));
  const action_opened = "browser_addon_browser_action_opened";
  const action_closed = "browser_addon_browser_action_closed";
  const blacklist_toggled_on = "browser_addon_browser_action_blacklist_toggled_on";
  const blacklist_toggled_off = "browser_addon_browser_action_blacklist_toggled_off";
  const glossary_toggled_on = "browser_addon_browser_action_glossary_toggled_on";
  const glossary_toggled_off = "browser_addon_browser_action_glossary_toggled_off";
  const glossary_link_clicked = "browser_addon_browser_action_glossary_link_clicked";
  const options_opened = "browser_addon_options_page_opened";
  const remove_blacklisted_site_clicked = "browser_addon_options_page_remove_blacklisted_site_clicked";
  const add_blacklisted_site_clicked = "browser_addon_options_page_add_blacklisted_site_clicked";
  const language_choice_clicked = "browser_addon_options_page_language_choice_clicked";
  const new_installation = "browser_addon_new_installation";
  const updated = "browser_addon_updated";
  const unspecified_install_event = "browser_addon_unspecified_install_event";
  const tooltip_anchor_hovered = "browser_addon_tab_tooltip_anchor_hovered";
  const tooltip_link_clicked = "browser_addon_tab_tooltip_link_clicked";
  const term_list_calculated = "browser_addon_tab_term_list_calculated";
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var webext_options_sync__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7);
  var webext_options_sync__WEBPACK_IMPORTED_MODULE_0___default = __webpack_require__.n(webext_options_sync__WEBPACK_IMPORTED_MODULE_0__);
  __webpack_exports__["a"] = new webext_options_sync__WEBPACK_IMPORTED_MODULE_0___default.a({
    defaults: {
      blacklistedSites: [],
      lang: "auto",
      snippetsLastFetched: {
        en: 1591717064327,
        de: 1591717064327
      }
    },
    migrations: [ webext_options_sync__WEBPACK_IMPORTED_MODULE_0___default.a.migrations.removeUnused ],
    logging: true
  });
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return sendMessageToContentScript;
  }));
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return sendMessageToBackgroundScript;
  }));
  function sendMessageToContentScript(message) {
    return browser.tabs.query({
      currentWindow: true,
      active: true
    }).then(tabs => browser.tabs.sendMessage(tabs[0].id, message)).catch(console.log);
  }
  function sendMessageToBackgroundScript(message) {
    return browser.runtime.sendMessage(message).catch(console.log);
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return track;
  }));
  var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6);
  var _options_storage__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2);
  var _messaging__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3);
  !function() {
    const analytics = window.analytics = window.analytics || [];
    if (!analytics.initialize) {
      if (analytics.invoked) {
        window.console && console.error && console.error("Segment snippet included twice.");
      } else {
        analytics.invoked = !0;
        analytics.methods = [ "trackSubmit", "trackClick", "trackLink", "trackForm", "pageview", "identify", "reset", "group", "track", "ready", "alias", "debug", "page", "once", "off", "on" ];
        analytics.factory = function(t) {
          return function() {
            const e = Array.prototype.slice.call(arguments);
            e.unshift(t);
            analytics.push(e);
            return analytics;
          };
        };
        for (let t = 0; t < analytics.methods.length; t++) {
          const e = analytics.methods[t];
          analytics[e] = analytics.factory(e);
        }
        analytics.load = function(t, e) {
          const n = document.createElement("script");
          n.type = "text/javascript";
          n.async = !0;
          n.src = "https://cdn.segment.com/analytics.js/v1/" + t + "/analytics.min.js";
          const a = document.querySelectorAll("script")[0];
          a.parentNode.insertBefore(n, a);
          analytics._loadOptions = e;
        };
        analytics.SNIPPET_VERSION = "4.1.0";
        analytics.load(_config__WEBPACK_IMPORTED_MODULE_0__["c"]);
        analytics.page();
      }
    }
  }();
  function isFirefoxOrChrome() {
    if (Boolean(window.chrome) && (Boolean(window.chrome.webstore) || Boolean(window.chrome.runtime))) {
      return "chrome";
    }
    if (typeof InstallTrigger !== "undefined") {
      return "firefox";
    }
    console.log("!! browser identification unsuccessful");
    return "unknown";
  }
  async function track(title, _detailsObject = {}, _hostname) {
    const {version: version} = browser.runtime.getManifest();
    const browserName = isFirefoxOrChrome();
    const storageData = await _options_storage__WEBPACK_IMPORTED_MODULE_1__["a"].getAll();
    const hostname = _hostname || await Object(_messaging__WEBPACK_IMPORTED_MODULE_2__["b"])({
      subject: "getHostname"
    });
    const url = await Object(_messaging__WEBPACK_IMPORTED_MODULE_2__["b"])({
      subject: "getUrl"
    });
    const detailsObject = {
      ..._detailsObject,
      hostname: hostname,
      url: url,
      browserName: browserName,
      version: version,
      storageData: storageData
    };
    analytics.track(title, detailsObject);
  }
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return m;
  }));
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return l;
  }));
  var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
  var t, u, r, i = 0, o = [], c = preact__WEBPACK_IMPORTED_MODULE_0__["b"].__r, f = preact__WEBPACK_IMPORTED_MODULE_0__["b"].diffed, e = preact__WEBPACK_IMPORTED_MODULE_0__["b"].__c, a = preact__WEBPACK_IMPORTED_MODULE_0__["b"].unmount;
  function v(t, r) {
    preact__WEBPACK_IMPORTED_MODULE_0__["b"].__h && preact__WEBPACK_IMPORTED_MODULE_0__["b"].__h(u, t, i || r), 
    i = 0;
    var o = u.__H || (u.__H = {
      __: [],
      __h: []
    });
    return t >= o.__.length && o.__.push({}), o.__[t];
  }
  function m(n) {
    return i = 1, p(E, n);
  }
  function p(n, r, i) {
    var o = v(t++, 2);
    return o.t = n, o.__c || (o.__c = u, o.__ = [ i ? i(r) : E(void 0, r), function(n) {
      var t = o.t(o.__[0], n);
      o.__[0] !== t && (o.__[0] = t, o.__c.setState({}));
    } ]), o.__;
  }
  function l(r, i) {
    var o = v(t++, 3);
    !preact__WEBPACK_IMPORTED_MODULE_0__["b"].__s && x(o.__H, i) && (o.__ = r, o.__H = i, 
    u.__H.__h.push(o));
  }
  function y(r, i) {
    var o = v(t++, 4);
    !preact__WEBPACK_IMPORTED_MODULE_0__["b"].__s && x(o.__H, i) && (o.__ = r, o.__H = i, 
    u.__h.push(o));
  }
  function d(n) {
    return i = 5, h((function() {
      return {
        current: n
      };
    }), []);
  }
  function s(n, t, u) {
    i = 6, y((function() {
      "function" == typeof n ? n(t()) : n && (n.current = t());
    }), null == u ? u : u.concat(n));
  }
  function h(n, u) {
    var r = v(t++, 7);
    return x(r.__H, u) ? (r.__H = u, r.__h = n, r.__ = n()) : r.__;
  }
  function T(n, t) {
    return i = 8, h((function() {
      return n;
    }), t);
  }
  function w(n) {
    var r = u.context[n.__c], i = v(t++, 9);
    return i.__c = n, r ? (null == i.__ && (i.__ = !0, r.sub(u)), r.props.value) : n.__;
  }
  function A(t, u) {
    preact__WEBPACK_IMPORTED_MODULE_0__["b"].useDebugValue && preact__WEBPACK_IMPORTED_MODULE_0__["b"].useDebugValue(u ? u(t) : t);
  }
  function F(n) {
    var r = v(t++, 10), i = m();
    return r.__ = n, u.componentDidCatch || (u.componentDidCatch = function(n) {
      r.__ && r.__(n), i[1](n);
    }), [ i[0], function() {
      i[1](void 0);
    } ];
  }
  function _() {
    o.some((function(t) {
      if (t.__P) try {
        t.__H.__h.forEach(g), t.__H.__h.forEach(q), t.__H.__h = [];
      } catch (u) {
        return t.__H.__h = [], preact__WEBPACK_IMPORTED_MODULE_0__["b"].__e(u, t.__v), !0;
      }
    })), o = [];
  }
  function g(n) {
    "function" == typeof n.u && n.u();
  }
  function q(n) {
    n.u = n.__();
  }
  function x(n, t) {
    return !n || t.some((function(t, u) {
      return t !== n[u];
    }));
  }
  function E(n, t) {
    return "function" == typeof t ? t(n) : t;
  }
  preact__WEBPACK_IMPORTED_MODULE_0__["b"].__r = function(n) {
    c && c(n), t = 0;
    var r = (u = n.__c).__H;
    r && (r.__h.forEach(g), r.__h.forEach(q), r.__h = []);
  }, preact__WEBPACK_IMPORTED_MODULE_0__["b"].diffed = function(t) {
    f && f(t);
    var u = t.__c;
    u && u.__H && u.__H.__h.length && (1 !== o.push(u) && r === preact__WEBPACK_IMPORTED_MODULE_0__["b"].requestAnimationFrame || ((r = preact__WEBPACK_IMPORTED_MODULE_0__["b"].requestAnimationFrame) || function(n) {
      var t, u = function() {
        clearTimeout(r), cancelAnimationFrame(t), setTimeout(n);
      }, r = setTimeout(u, 100);
      "undefined" != typeof window && (t = requestAnimationFrame(u));
    })(_));
  }, preact__WEBPACK_IMPORTED_MODULE_0__["b"].__c = function(t, u) {
    u.some((function(t) {
      try {
        t.__h.forEach(g), t.__h = t.__h.filter((function(n) {
          return !n.__ || q(n);
        }));
      } catch (r) {
        u.some((function(n) {
          n.__h && (n.__h = []);
        })), u = [], preact__WEBPACK_IMPORTED_MODULE_0__["b"].__e(r, t.__v);
      }
    })), e && e(t, u);
  }, preact__WEBPACK_IMPORTED_MODULE_0__["b"].unmount = function(t) {
    a && a(t);
    var u = t.__c;
    if (u && u.__H) try {
      u.__H.__.forEach(g);
    } catch (t) {
      preact__WEBPACK_IMPORTED_MODULE_0__["b"].__e(t, u.__v);
    }
  };
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.d(__webpack_exports__, "a", (function() {
    return BASE_URL;
  }));
  __webpack_require__.d(__webpack_exports__, "c", (function() {
    return SEGMENT_WRITE_KEY;
  }));
  __webpack_require__.d(__webpack_exports__, "b", (function() {
    return INSTALL_URL;
  }));
  __webpack_require__.d(__webpack_exports__, "d", (function() {
    return UNINSTALL_URL;
  }));
  const BASE_URL = "https://next.amboss.com/";
  const INSTALL_URL = "https://go.amboss.com/browser-plugin-install-en";
  const UNINSTALL_URL = "https://go.amboss.com/browser-plugin-uninstall-en";
  const SEGMENT_WRITE_KEY = "XS0G3taLBntvZPu5pRFQWHlEkP45pVuM";
}, function(module, exports, __webpack_require__) {
  "use strict";
  const webext_detect_page_1 = __webpack_require__(8);
  class OptionsSync {
    constructor(options) {
      const fullOptions = {
        defaults: {},
        storageName: "options",
        migrations: [],
        logging: true,
        ...options
      };
      this.storageName = fullOptions.storageName;
      this.defaults = fullOptions.defaults;
      if (fullOptions.logging === false) {
        this._log = () => {};
      }
      if (webext_detect_page_1.isBackgroundPage()) {
        chrome.management.getSelf(({installType: installType}) => {
          if (installType === "development") {
            this._applyDefinition(fullOptions);
          } else {
            chrome.runtime.onInstalled.addListener(() => this._applyDefinition(fullOptions));
          }
        });
      }
      this._handleFormUpdatesDebounced = this._handleFormUpdatesDebounced.bind(this);
    }
    _log(method, ...args) {
      console[method](...args);
    }
    async _applyDefinition(defs) {
      const options = {
        ...defs.defaults,
        ...await this.getAll()
      };
      this._log("group", "Appling definitions");
      this._log("info", "Current options:", options);
      if (defs.migrations && defs.migrations.length > 0) {
        this._log("info", "Running", defs.migrations.length, "migrations");
        defs.migrations.forEach(migrate => migrate(options, defs.defaults));
      }
      this._log("info", "Migrated options:", options);
      this._log("groupEnd");
      this.setAll(options);
    }
    _parseNumbers(options) {
      for (const name of Object.keys(options)) {
        if (options[name] === String(Number(options[name]))) {
          options[name] = Number(options[name]);
        }
      }
      return options;
    }
    async getAll() {
      const keys = await new Promise((resolve, reject) => {
        chrome.storage.sync.get({
          [this.storageName]: this.defaults
        }, result => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve(result);
          }
        });
      });
      return this._parseNumbers(keys[this.storageName]);
    }
    async setAll(newOptions) {
      return new Promise((resolve, reject) => {
        chrome.storage.sync.set({
          [this.storageName]: newOptions
        }, () => {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
          } else {
            resolve();
          }
        });
      });
    }
    async set(newOptions) {
      return this.setAll({
        ...await this.getAll(),
        ...newOptions
      });
    }
    async syncForm(form) {
      const element = form instanceof HTMLFormElement ? form : document.querySelector(form);
      element.addEventListener("input", this._handleFormUpdatesDebounced);
      element.addEventListener("change", this._handleFormUpdatesDebounced);
      chrome.storage.onChanged.addListener((changes, namespace) => {
        if (namespace === "sync" && changes[this.storageName] && !element.contains(document.activeElement)) {
          this._applyToForm(changes[this.storageName].newValue, element);
        }
      });
      this._applyToForm(await this.getAll(), element);
    }
    _applyToForm(options, form) {
      this._log("group", "Updating form");
      for (const name of Object.keys(options)) {
        const els = form.querySelectorAll(`[name="${CSS.escape(name)}"]`);
        const [field] = els;
        if (field) {
          this._log("info", name, ":", options[name]);
          switch (field.type) {
           case "checkbox":
            field.checked = options[name];
            break;

           case "radio":
            {
              const [selected] = [ ...els ].filter(el => el.value === options[name]);
              if (selected) {
                selected.checked = true;
              }
              break;
            }

           default:
            field.value = options[name];
            break;
          }
          field.dispatchEvent(new InputEvent("input"));
        } else {
          this._log("warn", "Stored option {", name, ":", options[name], "} was not found on the page");
        }
      }
      this._log("groupEnd");
    }
    _handleFormUpdatesDebounced({target: target}) {
      if (this._timer) {
        clearTimeout(this._timer);
      }
      this._timer = setTimeout(() => {
        this._handleFormUpdates(target);
        this._timer = undefined;
      }, 600);
    }
    _handleFormUpdates(el) {
      const {name: name} = el;
      let {value: value} = el;
      if (!name || !el.validity.valid) {
        return;
      }
      switch (el.type) {
       case "select-one":
        value = el.options[el.selectedIndex].value;
        break;

       case "checkbox":
        value = el.checked;
        break;

       default:
        break;
      }
      this._log("info", "Saving option", el.name, "to", value);
      this.set({
        [name]: value
      });
    }
  }
  OptionsSync.migrations = {
    removeUnused(options, defaults) {
      for (const key of Object.keys(options)) {
        if (!(key in defaults)) {
          delete options[key];
        }
      }
    }
  };
  module.exports = OptionsSync;
}, function(module, exports, __webpack_require__) {
  "use strict";
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  function isBackgroundPage() {
    return location.pathname === "/_generated_background_page.html" && !location.protocol.startsWith("http") && Boolean(typeof chrome === "object" && chrome.runtime);
  }
  exports.isBackgroundPage = isBackgroundPage;
  function isContentScript() {
    return location.protocol.startsWith("http") && Boolean(typeof chrome === "object" && chrome.runtime);
  }
  exports.isContentScript = isContentScript;
  function isOptionsPage() {
    if (typeof chrome !== "object" || !chrome.runtime) {
      return false;
    }
    const {options_ui: options_ui} = chrome.runtime.getManifest();
    if (typeof options_ui !== "object" || typeof options_ui.page !== "string") {
      return false;
    }
    const url = new URL(options_ui.page, location.origin);
    return url.pathname === location.pathname && url.origin === location.origin;
  }
  exports.isOptionsPage = isOptionsPage;
}, function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  var n = function(t, s, r, e) {
    var u;
    s[0] = 0;
    for (var h = 1; h < s.length; h++) {
      var p = s[h++], a = s[h] ? (s[0] |= p ? 1 : 2, r[s[h++]]) : s[++h];
      3 === p ? e[0] = a : 4 === p ? e[1] = Object.assign(e[1] || {}, a) : 5 === p ? (e[1] = e[1] || {})[s[++h]] = a : 6 === p ? e[1][s[++h]] += a + "" : p ? (u = t.apply(a, n(t, a, r, [ "", null ])), 
      e.push(u), a[0] ? s[0] |= 2 : (s[h - 2] = 0, s[h] = u)) : e.push(a);
    }
    return e;
  }, t = new Map;
  __webpack_exports__["a"] = function(s) {
    var r = t.get(this);
    return r || (r = new Map, t.set(this, r)), (r = n(this, r.get(s) || (r.set(s, r = function(n) {
      for (var t, s, r = 1, e = "", u = "", h = [ 0 ], p = function(n) {
        1 === r && (n || (e = e.replace(/^\s*\n\s*|\s*\n\s*$/g, ""))) ? h.push(0, n, e) : 3 === r && (n || e) ? (h.push(3, n, e), 
        r = 2) : 2 === r && "..." === e && n ? h.push(4, n, 0) : 2 === r && e && !n ? h.push(5, 0, !0, e) : r >= 5 && ((e || !n && 5 === r) && (h.push(r, 0, e, s), 
        r = 6), n && (h.push(r, n, 0, s), r = 6)), e = "";
      }, a = 0; a < n.length; a++) {
        a && (1 === r && p(), p(a));
        for (var l = 0; l < n[a].length; l++) t = n[a][l], 1 === r ? "<" === t ? (p(), h = [ h ], 
        r = 3) : e += t : 4 === r ? "--" === e && ">" === t ? (r = 1, e = "") : e = t + e[0] : u ? t === u ? u = "" : e += t : '"' === t || "'" === t ? u = t : ">" === t ? (p(), 
        r = 1) : r && ("=" === t ? (r = 5, s = e, e = "") : "/" === t && (r < 5 || ">" === n[a][l + 1]) ? (p(), 
        3 === r && (h = h[0]), r = h, (h = h[0]).push(2, 0, r), r = 0) : " " === t || "\t" === t || "\n" === t || "\r" === t ? (p(), 
        r = 2) : e += t), 3 === r && "!--" === e && (r = 4, h = h[0]);
      }
      return p(), h;
    }(s)), r), arguments, [])).length > 1 ? r : r[0];
  };
}, , , , function(module, __webpack_exports__, __webpack_require__) {
  "use strict";
  __webpack_require__.r(__webpack_exports__);
  var preact__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(0);
  var htm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9);
  var preact_hooks__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5);
  var _options_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2);
  var _messaging__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3);
  var _config__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6);
  var _tracking_helpers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4);
  var _event_names__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1);
  const html = htm__WEBPACK_IMPORTED_MODULE_1__["a"].bind(preact__WEBPACK_IMPORTED_MODULE_0__["a"]);
  const BrowserAction = () => {
    const [hostname, setHostname] = Object(preact_hooks__WEBPACK_IMPORTED_MODULE_2__["b"])("");
    const [isBlacklisted, setIsBlacklisted] = Object(preact_hooks__WEBPACK_IMPORTED_MODULE_2__["b"])(false);
    const [isShowGlossary, setIsShowGlossary] = Object(preact_hooks__WEBPACK_IMPORTED_MODULE_2__["b"])(true);
    const [language, setLanguage] = Object(preact_hooks__WEBPACK_IMPORTED_MODULE_2__["b"])("en");
    const [terms, setTerms] = Object(preact_hooks__WEBPACK_IMPORTED_MODULE_2__["b"])([]);
    Object(preact_hooks__WEBPACK_IMPORTED_MODULE_2__["a"])(() => Object(_messaging__WEBPACK_IMPORTED_MODULE_4__["b"])({
      subject: "getHostname"
    }).then(res => {
      setHostname(res.hostname);
    }), []);
    Object(preact_hooks__WEBPACK_IMPORTED_MODULE_2__["a"])(() => {
      const getStorageData = async () => {
        const {blacklistedSites: blacklistedSites, lang: lang} = await _options_storage__WEBPACK_IMPORTED_MODULE_3__["a"].getAll();
        setIsBlacklisted(blacklistedSites.some(i => i === hostname));
        setLanguage(lang);
      };
      if (hostname) {
        getStorageData();
      }
    }, [ hostname ]);
    Object(preact_hooks__WEBPACK_IMPORTED_MODULE_2__["a"])(() => {
      if (!terms.length) {
        Object(_messaging__WEBPACK_IMPORTED_MODULE_4__["b"])({
          subject: "getSnippetsMatchingText"
        }).then(setTerms);
      }
    }, [ language ]);
    Object(preact_hooks__WEBPACK_IMPORTED_MODULE_2__["a"])(() => {
      if (hostname) {
        Object(_tracking_helpers__WEBPACK_IMPORTED_MODULE_6__["a"])(_event_names__WEBPACK_IMPORTED_MODULE_7__["b"]);
      }
    }, [ hostname ]);
    const onIsBlacklistedClick = async e => {
      setIsBlacklisted(e.target.checked);
      const {blacklistedSites: blacklistedSites} = await _options_storage__WEBPACK_IMPORTED_MODULE_3__["a"].getAll();
      if (e.target.checked) {
        setTerms([]);
        setIsShowGlossary(false);
      } else if (!e.target.checked && !terms.length) {
        Object(_messaging__WEBPACK_IMPORTED_MODULE_4__["b"])({
          subject: "getSnippetsMatchingText",
          language: language
        }, 0).then(setTerms);
      }
      await _options_storage__WEBPACK_IMPORTED_MODULE_3__["a"].set({
        blacklistedSites: e.target.checked ? [ ...blacklistedSites, hostname ] : [ ...new Set(blacklistedSites.filter(i => i !== hostname)) ]
      });
      Object(_tracking_helpers__WEBPACK_IMPORTED_MODULE_6__["a"])(e.target.checked ? _event_names__WEBPACK_IMPORTED_MODULE_7__["e"] : _event_names__WEBPACK_IMPORTED_MODULE_7__["d"]);
    };
    const onIsShowGlossary = () => {
      setIsShowGlossary(!isShowGlossary);
      if (isShowGlossary && !terms.length) {
        Object(_messaging__WEBPACK_IMPORTED_MODULE_4__["b"])({
          subject: "getSnippetsMatchingText",
          language: language
        }, 0).then(setTerms);
      }
      Object(_tracking_helpers__WEBPACK_IMPORTED_MODULE_6__["a"])(isShowGlossary ? _event_names__WEBPACK_IMPORTED_MODULE_7__["h"] : _event_names__WEBPACK_IMPORTED_MODULE_7__["g"]);
    };
    return html`<div class="app">
			<div className="settings_bar">
					<svg width="140" viewBox="0 0 102 17" fill="none" xmlns="http://www.w3.org/2000/svg">
						<mask id="mask0" mask-type="alpha" maskUnits="userSpaceOnUse" x="0" y="0" width="16" height="17">
							<path fill-rule="evenodd" clip-rule="evenodd" d="M0 0.87207H15.0659V16.6997H0V0.87207Z" fill="white"/>
						</mask>
						<g mask="url(#mask0)">
							<path fill-rule="evenodd" clip-rule="evenodd" d="M12.0472 15.6584H3.01465L3.58547 14.6171H11.4764L12.0472 15.6584ZM8.72977 5.2334L13.3032 13.5758H12.0977L8.72315 7.42013L8.12696 8.50715L10.9056 13.5758H4.15637L8.72977 5.2334ZM15.0661 14.6171L8.72311 3.04666L8.13375 4.1461L2.9643 13.5758H1.7589L8.127 1.95923L7.53101 0.87207L-0.00402832 14.6171H2.39348L1.25183 16.6997H13.8103L12.6685 14.6171H15.0661Z" fill="#24A3AA"/>
						</g>
						<path fill-rule="evenodd" clip-rule="evenodd" d="M23.7406 10.9808H30.5153L27.4271 3.55892C27.3772 3.44132 27.3273 3.30815 27.2775 3.15928C27.2276 3.01054 27.1777 2.85306 27.1279 2.68698C27.078 2.85306 27.0281 3.01054 26.9783 3.15928C26.9284 3.30815 26.8785 3.44474 26.8287 3.5693L23.7406 10.9808ZM33.8599 16.3162H33.0157C32.9159 16.3162 32.834 16.2902 32.7699 16.2383C32.7058 16.1864 32.6559 16.1189 32.6203 16.0359L30.8358 11.7696H23.4092L21.6354 16.0359C21.6069 16.1122 21.557 16.1779 21.4858 16.2331C21.4145 16.2887 21.329 16.3162 21.2294 16.3162H20.3959L26.5829 1.62817H27.6728L33.8599 16.3162Z" fill="#000105"/>
						<path fill-rule="evenodd" clip-rule="evenodd" d="M43.3173 12.6623C43.3594 12.5517 43.403 12.4427 43.4487 12.3354C43.4941 12.2281 43.5448 12.1261 43.601 12.0291L49.4426 1.8254C49.4986 1.73553 49.5546 1.68007 49.6107 1.65931C49.6667 1.63855 49.7437 1.62817 49.8418 1.62817H50.5878V16.3162H49.6422V3.79764C49.6422 3.61776 49.6527 3.4275 49.6737 3.22673L43.8216 13.4928C43.7234 13.6728 43.5834 13.7626 43.4014 13.7626H43.2332C43.0581 13.7626 42.9181 13.6728 42.8129 13.4928L36.8033 3.21635C36.8243 3.41712 36.8349 3.61079 36.8349 3.79764V16.3162H35.8998V1.62817H36.6352C36.7332 1.62817 36.812 1.63855 36.8716 1.65931C36.9311 1.68007 36.9889 1.73553 37.045 1.8254L43.0442 12.0395C43.1492 12.2333 43.2402 12.4409 43.3173 12.6623Z" fill="#000105"/>
						<path fill-rule="evenodd" clip-rule="evenodd" d="M55.3269 9.27838V15.465H59.0408C60.3449 15.465 61.3283 15.1865 61.9909 14.6294C62.6535 14.0724 62.9847 13.2887 62.9847 12.2783C62.9847 11.8147 62.8958 11.3977 62.718 11.0274C62.5401 10.6574 62.2838 10.3424 61.9491 10.0828C61.6144 9.82334 61.2028 9.62455 60.7147 9.48599C60.2264 9.34763 59.6719 9.27838 59.0513 9.27838H55.3269ZM55.3269 8.4999H58.5386C59.222 8.4999 59.8061 8.41344 60.2909 8.24039C60.7756 8.06748 61.1732 7.83911 61.4836 7.5553C61.7938 7.27162 62.0224 6.94983 62.1687 6.58994C62.3153 6.23018 62.3885 5.85991 62.3885 5.47926C62.3885 4.48972 62.0727 3.74057 61.4416 3.23194C60.8103 2.72331 59.8358 2.46899 58.5177 2.46899H55.3269V8.4999ZM54.2599 16.3162V1.62817H58.5177C59.3615 1.62817 60.0921 1.71122 60.7094 1.8773C61.3265 2.04338 61.8373 2.28732 62.242 2.6091C62.6463 2.93089 62.9481 3.3237 63.147 3.78726C63.3456 4.25095 63.4451 4.77693 63.4451 5.36505C63.4451 5.75267 63.377 6.12636 63.241 6.48611C63.105 6.84601 62.9079 7.17817 62.65 7.48261C62.3919 7.78719 62.0762 8.05189 61.7032 8.2767C61.33 8.50165 60.903 8.67292 60.4217 8.79052C61.5864 8.96357 62.4826 9.34764 63.1102 9.94272C63.738 10.538 64.0519 11.3233 64.0519 12.299C64.0519 12.9218 63.9402 13.4824 63.717 13.9806C63.4938 14.4789 63.1695 14.9011 62.7442 15.247C62.3186 15.5931 61.7956 15.8578 61.1749 16.0411C60.5542 16.2245 59.8497 16.3162 59.0617 16.3162H54.2599Z" fill="#000105"/>
						<mask id="mask1" mask-type="alpha" maskUnits="userSpaceOnUse" x="66" y="1" width="36" height="16">
							<path fill-rule="evenodd" clip-rule="evenodd" d="M66.1226 1.63208H101.959V16.7201H66.1226V1.63208Z" fill="white"/>
						</mask>
						<g mask="url(#mask1)">
							<path fill-rule="evenodd" clip-rule="evenodd" d="M79.2436 9.17295C79.2436 8.14396 79.0992 7.21912 78.811 6.39858C78.5221 5.57818 78.1158 4.88281 77.5915 4.31259C77.0671 3.74251 76.4359 3.3061 75.6963 3.00363C74.958 2.70116 74.1379 2.54993 73.2372 2.54993C72.3503 2.54993 71.5392 2.70116 70.8037 3.00363C70.0683 3.3061 69.4351 3.74251 68.9039 4.31259C68.3725 4.88281 67.9609 5.57818 67.6688 6.39858C67.3768 7.21912 67.2308 8.14396 67.2308 9.17295C67.2308 10.2091 67.3768 11.1356 67.6688 11.9525C67.9609 12.7696 68.3725 13.4632 68.9039 14.0333C69.4351 14.6035 70.0683 15.0382 70.8037 15.3371C71.5392 15.6361 72.3503 15.7856 73.2372 15.7856C74.1379 15.7856 74.958 15.6361 75.6963 15.3371C76.4359 15.0382 77.0671 14.6035 77.5915 14.0333C78.1158 13.4632 78.5221 12.7696 78.811 11.9525C79.0992 11.1356 79.2436 10.2091 79.2436 9.17295ZM80.3626 9.17294C80.3626 10.3134 80.1903 11.3476 79.8452 12.2758C79.5007 13.2041 79.0146 13.9968 78.3889 14.6539C77.7618 15.311 77.0124 15.8186 76.1402 16.1767C75.2672 16.5349 74.2999 16.7138 73.2373 16.7138C72.1887 16.7138 71.2282 16.5349 70.3553 16.1767C69.4829 15.8186 68.7333 15.311 68.1071 14.6539C67.4807 13.9968 66.9935 13.2041 66.6451 12.2758C66.2967 11.3476 66.1226 10.3134 66.1226 9.17294C66.1226 8.03965 66.2967 7.00873 66.6451 6.08046C66.9935 5.15219 67.4807 4.35952 68.1071 3.70243C68.7333 3.04534 69.4829 2.53606 70.3553 2.17444C71.2282 1.81296 72.1887 1.63208 73.2373 1.63208C74.2999 1.63208 75.2672 1.81117 76.1402 2.16922C77.0124 2.52741 77.7618 3.03669 78.3889 3.69721C79.0146 4.35787 79.5007 5.15219 79.8452 6.08046C80.1903 7.00873 80.3626 8.03965 80.3626 9.17294Z" fill="#000105"/>
							<path fill-rule="evenodd" clip-rule="evenodd" d="M90.0524 3.59291C89.9892 3.71121 89.8975 3.77022 89.7781 3.77022C89.6864 3.77022 89.5677 3.706 89.4232 3.57727C89.2788 3.44868 89.0822 3.30609 88.8357 3.14964C88.5885 2.99319 88.2794 2.84895 87.9086 2.7168C87.5384 2.58477 87.0815 2.51863 86.5377 2.51863C85.9939 2.51863 85.5154 2.5952 85.1029 2.74809C84.6897 2.9011 84.3439 3.1097 84.0647 3.37388C83.7855 3.6382 83.5737 3.9441 83.4293 4.29172C83.2848 4.63948 83.2126 5.00453 83.2126 5.38687C83.2126 5.88751 83.3195 6.30127 83.5348 6.62803C83.7494 6.95493 84.0335 7.23297 84.3855 7.46243C84.7376 7.69189 85.1377 7.88484 85.5856 8.04129C86.0328 8.19774 86.4926 8.35254 86.9648 8.50543C87.437 8.65844 87.8968 8.82718 88.344 9.01128C88.7919 9.19559 89.192 9.42683 89.5441 9.70487C89.8962 9.98305 90.1802 10.3255 90.3948 10.7322C90.6101 11.139 90.7177 11.6448 90.7177 12.2498C90.7177 12.8687 90.6101 13.451 90.3955 13.9968C90.1809 14.5428 89.8691 15.0174 89.4614 15.4205C89.0531 15.8238 88.5537 16.1419 87.9628 16.3748C87.3711 16.6077 86.696 16.7242 85.9356 16.7242C84.9501 16.7242 84.1022 16.5521 83.3918 16.208C82.6806 15.8638 82.0584 15.3928 81.5229 14.7946L81.8188 14.3358C81.9035 14.2314 82.0021 14.1793 82.1146 14.1793C82.1778 14.1793 82.2591 14.221 82.3577 14.3045C82.4563 14.3879 82.5758 14.4906 82.7167 14.6122C82.8577 14.7339 83.0272 14.8661 83.2244 15.0085C83.4216 15.1511 83.6508 15.2833 83.9112 15.4048C84.1723 15.5266 84.4717 15.6291 84.8099 15.7125C85.1481 15.796 85.5321 15.8377 85.962 15.8377C86.5544 15.8377 87.0829 15.749 87.5475 15.5717C88.0128 15.3944 88.4058 15.1529 88.7267 14.8468C89.0468 14.5409 89.292 14.1777 89.4614 13.7569C89.6302 13.3364 89.7149 12.886 89.7149 12.4062C89.7149 11.8847 89.6073 11.4555 89.3927 11.1181C89.1774 10.7809 88.8933 10.4993 88.5412 10.2733C88.1891 10.0474 87.7891 9.85789 87.3412 9.70487C86.894 9.55199 86.4342 9.40233 85.962 9.25638C85.4898 9.11036 85.03 8.94705 84.5828 8.76617C84.1348 8.58543 83.7348 8.35419 83.3827 8.07258C83.0306 7.79097 82.7466 7.43992 82.532 7.01916C82.3167 6.59853 82.2098 6.07181 82.2098 5.43902C82.2098 4.94538 82.3042 4.46903 82.4952 4.01011C82.6855 3.55119 82.9633 3.14621 83.33 2.79502C83.6966 2.44397 84.1494 2.16236 84.6883 1.95019C85.2272 1.73816 85.8418 1.63208 86.5328 1.63208C87.3079 1.63208 88.0037 1.75381 88.6204 1.99713C89.2371 2.24059 89.7989 2.6125 90.3059 3.11313L90.0524 3.59291Z" fill="#000105"/>
							<path fill-rule="evenodd" clip-rule="evenodd" d="M101.294 3.59291C101.231 3.71121 101.14 3.77022 101.02 3.77022C100.928 3.77022 100.81 3.706 100.665 3.57727C100.52 3.44868 100.324 3.30609 100.077 3.14964C99.8305 2.99319 99.5215 2.84895 99.1506 2.7168C98.7805 2.58477 98.3228 2.51863 97.7791 2.51863C97.236 2.51863 96.7575 2.5952 96.3443 2.74809C95.9318 2.9011 95.5852 3.1097 95.3068 3.37388C95.0276 3.6382 94.8158 3.9441 94.6713 4.29172C94.5262 4.63948 94.454 5.00453 94.454 5.38687C94.454 5.88751 94.5616 6.30127 94.7762 6.62803C94.9915 6.95493 95.2748 7.23297 95.6276 7.46243C95.9797 7.69189 96.3797 7.88484 96.827 8.04129C97.2749 8.19774 97.7346 8.35254 98.2069 8.50543C98.6791 8.65844 99.1388 8.82718 99.5861 9.01128C100.033 9.19559 100.433 9.42683 100.786 9.70487C101.138 9.98305 101.422 10.3255 101.637 10.7322C101.852 11.139 101.959 11.6448 101.959 12.2498C101.959 12.8687 101.852 13.451 101.638 13.9968C101.423 14.5428 101.111 15.0174 100.703 15.4205C100.295 15.8238 99.7951 16.1419 99.2041 16.3748C98.6131 16.6077 97.9374 16.7242 97.1777 16.7242C96.1922 16.7242 95.3443 16.5521 94.6338 16.208C93.9227 15.8638 93.2998 15.3928 92.765 14.7946L93.0609 14.3358C93.1449 14.2314 93.2435 14.1793 93.3567 14.1793C93.4199 14.1793 93.5012 14.221 93.5998 14.3045C93.6984 14.3879 93.8178 14.4906 93.9588 14.6122C94.0998 14.7339 94.2692 14.8661 94.4665 15.0085C94.6637 15.1511 94.8922 15.2833 95.1533 15.4048C95.4137 15.5266 95.713 15.6291 96.0519 15.7125C96.3901 15.796 96.7742 15.8377 97.2041 15.8377C97.7957 15.8377 98.3242 15.749 98.7895 15.5717C99.2548 15.3944 99.6479 15.1529 99.968 14.8468C100.289 14.5409 100.534 14.1777 100.703 13.7569C100.872 13.3364 100.956 12.886 100.956 12.4062C100.956 11.8847 100.849 11.4555 100.634 11.1181C100.419 10.7809 100.135 10.4993 99.7833 10.2733C99.4305 10.0474 99.0305 9.85789 98.5833 9.70487C98.136 9.55199 97.6763 9.40233 97.2041 9.25638C96.7318 9.11036 96.2721 8.94705 95.8241 8.76617C95.3769 8.58543 94.9769 8.35419 94.6248 8.07258C94.272 7.79097 93.9887 7.43992 93.7734 7.01916C93.5588 6.59853 93.4511 6.07181 93.4511 5.43902C93.4511 4.94538 93.5463 4.46903 93.7366 4.01011C93.9269 3.55119 94.2053 3.14621 94.572 2.79502C94.938 2.44397 95.3908 2.16236 95.9304 1.95019C96.4693 1.73816 97.0839 1.63208 97.7749 1.63208C98.5499 1.63208 99.2458 1.75381 99.8625 1.99713C100.479 2.24059 101.041 2.6125 101.548 3.11313L101.294 3.59291Z" fill="#000105"/>
						</g>
					</svg>
				<label for="isBlacklisted">
					<input type="checkbox" id="isBlacklisted" checked=${isBlacklisted} onClick=${onIsBlacklistedClick}/>
					${browser.i18n.getMessage("blacklistSite", hostname)}
				</label>
				<label for="isShowGlossary">
					<input type="checkbox" id="isShowGlossary" disabled=${isBlacklisted} checked=${isShowGlossary} onClick=${onIsShowGlossary}/>
					${browser.i18n.getMessage("showGlossary")}
				</label>
			</div>
			${!isShowGlossary && html`<div class="no-glossary"></div>`}
			${isShowGlossary && !isBlacklisted && terms && terms.length === 0 && html`<div class="lds-ripple-wrapper"><div class="lds-ripple"><div></div><div></div></div></div>`}
			${isShowGlossary && !isBlacklisted && terms && terms.length > 0 && terms.map(term => html`<${Term} ...${term} language=${language} />`)}
		</div>`;
  };
  function Term({title: title, etymology: etymology, description: description, id: id, destinations: destinations, language: language}) {
    const [isOpen, setIsOpen] = Object(preact_hooks__WEBPACK_IMPORTED_MODULE_2__["b"])(false);
    const [isClicked, setIsClicked] = Object(preact_hooks__WEBPACK_IMPORTED_MODULE_2__["b"])(false);
    const {anchor: anchor, label: label, lc_xid: lc_xid} = Array.isArray(destinations) && destinations[0] || {};
    const href = `${_config__WEBPACK_IMPORTED_MODULE_5__["a"]}${language === "en" ? "us" : "de"}/article/${lc_xid}#${anchor}`;
    const handleHeaderClick = () => {
      Object(_tracking_helpers__WEBPACK_IMPORTED_MODULE_6__["a"])(isOpen ? _event_names__WEBPACK_IMPORTED_MODULE_7__["b"] : _event_names__WEBPACK_IMPORTED_MODULE_7__["a"], {
        href: href,
        title: title
      });
      setIsOpen(!isOpen);
    };
    const handleLinkClick = event => {
      if (isClicked) {
        setIsClicked(false);
        return;
      }
      event.preventDefault();
      Object(_tracking_helpers__WEBPACK_IMPORTED_MODULE_6__["a"])(_event_names__WEBPACK_IMPORTED_MODULE_7__["f"], {
        href: href,
        title: title
      });
      setIsClicked(true);
      const newEvent = new MouseEvent("click", {
        view: window,
        bubbles: true,
        cancelable: true
      });
      setTimeout(() => {
        event.target.dispatchEvent(newEvent);
      }, 1e3);
    };
    return html`<div key=${id} class="ambossContent">
			<div class="ambossHeader" onClick=${handleHeaderClick}>${title}</div>
			${isOpen && html`<div>
				${Boolean(etymology) && html`<div class="ambossSnippetEtymology">${etymology}</div>`}
				<div class="ambossSnippetDescription">${description}</div>
				${Boolean(lc_xid) && html`<div id="ambossFooter" class="ambossFooter" >
					<a href=${href} target="_blank" onClick=${handleLinkClick}>
						<div class="icon_container">
							<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
								<rect x="4" y="2" width="16" height="20"></rect>
								<line x1="16" y1="6" x2="8" y2="6"></line>
								<line x1="14" y1="10" x2="8" y2="10"></line>
								<rect x="8" y="14" width="8" height="4"></rect>
							</svg>
						</div>
						<div class="link_arrow_container" >
							<h4>${label}</h4>
							<div class="arrow_container">
								<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
									<line x1="5" y1="12" x2="19" y2="12"></line>
									<polyline points="12 5 19 12 12 19"></polyline>
								</svg>
						</div>
					</div>
					</a>
				</div>`}
			</div>`}
		</div>`;
  }
  Object(preact__WEBPACK_IMPORTED_MODULE_0__["c"])(html`<${BrowserAction} />`, document.body);
} ]);